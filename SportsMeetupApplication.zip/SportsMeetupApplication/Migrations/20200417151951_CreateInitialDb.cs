﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SportsMeetupApplication.Migrations
{
    public partial class CreateInitialDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
