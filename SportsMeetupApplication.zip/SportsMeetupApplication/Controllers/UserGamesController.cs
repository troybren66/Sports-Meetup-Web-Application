﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsMeetupApplication.Models;
using SportsMeetupApplication.Data;

namespace SportsMeetupApplication.Controllers
{
    public class UserGamesController : Controller
    {
        private readonly WheresTheGameDatabaseContext _context;

        public UserGamesController(WheresTheGameDatabaseContext context)
        {
            _context = context;
        }

        // GET: UserGames
        public async Task<IActionResult> Index()
        {
            var WheresTheGameDatabaseContext = _context.UserGame.Include(u => u.Game).Include(u => u.User);
            return View(await WheresTheGameDatabaseContext.ToListAsync());
        }

        // GET: UserGames/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userGame = await _context.UserGame
                .Include(u => u.Game)
                .Include(u => u.User)
                .FirstOrDefaultAsync(m => m.UserGameId == id);
            if (userGame == null)
            {
                return NotFound();
            }

            return View(userGame);
        }

        // GET: UserGames/Create
        public IActionResult Create()
        {
            ViewData["GameId"] = new SelectList(_context.Games, "GameId", "GameId");
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId");
            return View();
        }

        // POST: UserGames/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UserGameId,UserId,GameId")] UserGame userGame)
        {
            if (ModelState.IsValid)
            {
                _context.Add(userGame);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["GameId"] = new SelectList(_context.Games, "GameId", "GameId", userGame.GameId);
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId", userGame.UserId);
            return View(userGame);
        }

        // GET: UserGames/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userGame = await _context.UserGame.FindAsync(id);
            if (userGame == null)
            {
                return NotFound();
            }
            ViewData["GameId"] = new SelectList(_context.Games, "GameId", "GameId", userGame.GameId);
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId", userGame.UserId);
            return View(userGame);
        }

        // POST: UserGames/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("UserGameId,UserId,GameId")] UserGame userGame)
        {
            if (id != userGame.UserGameId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(userGame);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserGameExists(userGame.UserGameId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["GameId"] = new SelectList(_context.Games, "GameId", "GameId", userGame.GameId);
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId", userGame.UserId);
            return View(userGame);
        }

        // GET: UserGames/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userGame = await _context.UserGame
                .Include(u => u.Game)
                .Include(u => u.User)
                .FirstOrDefaultAsync(m => m.UserGameId == id);
            if (userGame == null)
            {
                return NotFound();
            }

            return View(userGame);
        }

        // POST: UserGames/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var userGame = await _context.UserGame.FindAsync(id);
            _context.UserGame.Remove(userGame);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool UserGameExists(int id)
        {
            return _context.UserGame.Any(e => e.UserGameId == id);
        }
    }
}
