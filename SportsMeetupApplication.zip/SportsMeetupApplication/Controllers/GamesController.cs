﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsMeetupApplication.Models;
using SportsMeetupApplication.Data;


namespace SportsMeetupApplication.Controllers
{
    public class GamesController : Controller
    {
        private readonly WheresTheGameDatabaseContext _context;

        public GamesController(WheresTheGameDatabaseContext context)
        {
            _context = context;
        }

        // GET: Games
        public async Task<IActionResult> Index()
        {
            var WheresTheGameDatabaseContext = _context.Games.Include(g => g.Type).Include(g => g.User).Include(g => g.Venue);
            return View(await WheresTheGameDatabaseContext.ToListAsync());
        }

        // GET: Games/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var games = await _context.Games
                .Include(g => g.Type)
                .Include(g => g.User)
                .Include(g => g.Venue)
                .FirstOrDefaultAsync(m => m.GameId == id);
            if (games == null)
            {
                return NotFound();
            }

            return View(games);
        }

        // GET: Games/Create
        public IActionResult Create()
        {
            ViewData["TypeId"] = new SelectList(_context.GameType, "TypeId", "TypeId");
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId");
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueId");
            return View();
        }

        // POST: Games/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("GameId,Name,StartTimeDate,TypeId,VenueId,UserId,AdminId,Guests,Location,Description,MinParticipants,MaxParticipants")] Games games)
        {
            if (ModelState.IsValid)
            {
                _context.Add(games);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["TypeId"] = new SelectList(_context.GameType, "TypeId", "TypeId", games.TypeId);
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId", games.UserId);
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueId", games.VenueId);
            return View(games);
        }

        // GET: Games/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var games = await _context.Games.FindAsync(id);
            if (games == null)
            {
                return NotFound();
            }
            ViewData["TypeId"] = new SelectList(_context.GameType, "TypeId", "TypeId", games.TypeId);
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId", games.UserId);
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueId", games.VenueId);
            return View(games);
        }

        // POST: Games/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("GameId,Name,StartTimeDate,TypeId,VenueId,UserId,AdminId,Guests,Location,Description,MinParticipants,MaxParticipants")] Games games)
        {
            if (id != games.GameId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(games);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GamesExists(games.GameId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["TypeId"] = new SelectList(_context.GameType, "TypeId", "TypeId", games.TypeId);
            ViewData["UserId"] = new SelectList(_context.Users, "UserId", "UserId", games.UserId);
            ViewData["VenueId"] = new SelectList(_context.Venue, "VenueId", "VenueId", games.VenueId);
            return View(games);
        }

        // GET: Games/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var games = await _context.Games
                .Include(g => g.Type)
                .Include(g => g.User)
                .Include(g => g.Venue)
                .FirstOrDefaultAsync(m => m.GameId == id);
            if (games == null)
            {
                return NotFound();
            }

            return View(games);
        }

        // POST: Games/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var games = await _context.Games.FindAsync(id);
            _context.Games.Remove(games);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GamesExists(int id)
        {
            return _context.Games.Any(e => e.GameId == id);
        }
    }
}
