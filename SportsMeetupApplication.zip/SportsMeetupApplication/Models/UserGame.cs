﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsMeetupApplication.Models
{
    public partial class UserGame
    {
        public int UserGameId { get; set; }
        public int? UserId { get; set; }
        public int? GameId { get; set; }

        public virtual Games Game { get; set; }
        public virtual Users User { get; set; }
    }
}

