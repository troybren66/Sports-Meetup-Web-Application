﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsMeetupApplication.Models
{
    public partial class Venue
    {
        public Venue()
        {
            Games = new HashSet<Games>();
        }

        public int VenueId { get; set; }
        public string Address { get; set; }
        public string Name { get; set; }
        public string VenueType { get; set; }

        public virtual ICollection<Games> Games { get; set; }
    }
}
