﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsMeetupApplication.Models
{
    public partial class Users
    {
        public Users()
        {
            Games = new HashSet<Games>();
            UserGame = new HashSet<UserGame>();
        }

        public int UserId { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string EmailAddress { get; set; }

        public virtual ICollection<Games> Games { get; set; }
        public virtual ICollection<UserGame> UserGame { get; set; }
    }
}
