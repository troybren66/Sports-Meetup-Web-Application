﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsMeetupApplication.Models
{
    public partial class GameType
    {
        public GameType()
        {
            Games = new HashSet<Games>();
        }

        public int TypeId { get; set; }
        public string TypeName { get; set; }

        public virtual ICollection<Games> Games { get; set; }
    }
}
