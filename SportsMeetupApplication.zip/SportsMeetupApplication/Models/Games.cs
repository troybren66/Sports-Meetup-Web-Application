﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SportsMeetupApplication.Models
{
    public partial class Games
    {
        public Games()
        {
            UserGame = new HashSet<UserGame>();
        }

        public int GameId { get; set; }
        public string Name { get; set; }
        public int? StartTimeDate { get; set; }
        public int? TypeId { get; set; }
        public int? VenueId { get; set; }
        public int? UserId { get; set; }
        public int? AdminId { get; set; }
        public string Guests { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
        public int? MinParticipants { get; set; }
        public int? MaxParticipants { get; set; }

        public virtual GameType Type { get; set; }
        public virtual Users User { get; set; }
        public virtual Venue Venue { get; set; }
        public virtual ICollection<UserGame> UserGame { get; set; }
    }
}


