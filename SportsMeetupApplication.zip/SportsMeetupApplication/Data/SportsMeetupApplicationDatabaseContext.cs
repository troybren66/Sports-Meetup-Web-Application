﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using SportsMeetupApplication.Models;

namespace SportsMeetupApplication.Data
{
    public partial class WheresTheGameDatabaseContext : DbContext
    {
        public WheresTheGameDatabaseContext()
        {
        }

        public WheresTheGameDatabaseContext(DbContextOptions<WheresTheGameDatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<GameType> GameType { get; set; }
        public virtual DbSet<Games> Games { get; set; }
        public virtual DbSet<UserGame> UserGame { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<Venue> Venue { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.\\;Database=WheresTheGameDatabase;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<GameType>(entity =>
            {
                entity.HasKey(e => e.TypeId)
                    .HasName("PK__GameType__516F0395DBCAE182");

                entity.Property(e => e.TypeId)
                    .HasColumnName("TypeID")
                    .ValueGeneratedNever();

                entity.Property(e => e.TypeName).HasColumnName("Type Name");
            });

            modelBuilder.Entity<Games>(entity =>
            {
                entity.HasKey(e => e.GameId)
                    .HasName("PK__Games__2AB897DDD2C71196");

                entity.Property(e => e.GameId)
                    .HasColumnName("GameID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AdminId).HasColumnName("Admin ID");

                entity.Property(e => e.MaxParticipants).HasColumnName("Max Participants");

                entity.Property(e => e.MinParticipants).HasColumnName("Min Participants");

                entity.Property(e => e.StartTimeDate).HasColumnName("Start Time Date");

                entity.Property(e => e.TypeId).HasColumnName("TypeID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.VenueId).HasColumnName("VenueID");

                entity.HasOne(d => d.Type)
                    .WithMany(p => p.Games)
                    .HasForeignKey(d => d.TypeId)
                    .HasConstraintName("FK__Games__TypeID__2D27B809");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Games)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__Games__UserID__2C3393D0");

                entity.HasOne(d => d.Venue)
                    .WithMany(p => p.Games)
                    .HasForeignKey(d => d.VenueId)
                    .HasConstraintName("FK__Games__VenueID__2E1BDC42");
            });

            modelBuilder.Entity<UserGame>(entity =>
            {
                entity.Property(e => e.UserGameId).ValueGeneratedNever();

                entity.Property(e => e.GameId).HasColumnName("GameID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Game)
                    .WithMany(p => p.UserGame)
                    .HasForeignKey(d => d.GameId)
                    .HasConstraintName("FK__UserGame__GameID__300424B4");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserGame)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__UserGame__UserID__2F10007B");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__Users__1788CCAC353B0A7E");

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .ValueGeneratedNever();

                entity.Property(e => e.EmailAddress).HasColumnName("Email Address");
            });

            modelBuilder.Entity<Venue>(entity =>
            {
                entity.Property(e => e.VenueId)
                    .HasColumnName("VenueID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Address).HasMaxLength(1);

                entity.Property(e => e.Name).HasMaxLength(1);

                entity.Property(e => e.VenueType)
                    .HasColumnName("Venue Type")
                    .HasMaxLength(1);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}


